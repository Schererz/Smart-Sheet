# Como rodar os testes

Passo a passo pra colocar o app de pé, do zero, sempre que for retomar os testes.

## 1. Suba o backend

Abra um terminal, na pasta `backend`:

```
venv\Scripts\activate
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Deixe esse terminal aberto rodando. Se aparecer `Uvicorn running on http://0.0.0.0:8000`, deu certo.

> Se der erro de "unable to create process" ou o `venv` não ativar, o
> ambiente virtual pode estar corrompido — apague a pasta `venv` e recrie
> com `py -3.12 -m venv venv` (não use `python -m venv venv` direto, pra
> evitar pegar a versão da Microsoft Store por engano).

## 2. Confira o IP da sua máquina

Esse IP pode mudar entre uma sessão e outra (principalmente se o roteador
reiniciar). Abra outro terminal e rode:

```
ipconfig
```

Anote o "Endereço IPv4" da sua conexão Wi-Fi.

## 3. Confirme o IP no app

Abra `frontend/lib/services/api_service.dart` e confira se o `baseUrl` bate
com o IP que você acabou de achar:

```dart
class ApiConfig {
  static const baseUrl = 'http://SEU_IP_AQUI:8000';
}
```

Se mudou, atualize e salve.

## 4. Conecte o celular

- Cabo USB conectado no PC
- Celular com a tela desbloqueada
- Depuração USB ativada (Configurações > Sobre o telefone > toque 7x em
  "Número da versão" > Opções do desenvolvedor > Depuração USB)
- Aceite o pop-up "Confiar neste computador?" se ele aparecer

Confirme que o celular foi reconhecido:

```
flutter devices
```

## 5. Rode o app

Na pasta `frontend`:

```
flutter run
```

Se pedir pra escolher o dispositivo, selecione o número do seu celular.
A primeira compilação demora alguns minutos — as próximas são bem mais rápidas.

## 6. Testando de novo sem recompilar tudo

Com o app já rodando, não precisa fechar e rodar `flutter run` de novo a
cada mudança:

- **`r`** (minúsculo) no terminal → hot reload (aplica mudanças de código na hora)
- **`R`** (maiúsculo) → hot restart (reinicia o app do zero, mantendo a conexão)
- Puxar a lista pra baixo dentro do app → recarrega os dados do backend

## Checklist rápido se algo não conectar

- [ ] O terminal do backend ainda está rodando (`Uvicorn running on...`)?
- [ ] O IP em `api_service.dart` bate com o `ipconfig` de agora?
- [ ] Celular e PC estão na mesma rede Wi-Fi?
- [ ] O Firewall do Windows tem uma regra liberando a porta 8000? (Firewall
  do Windows Defender > Configurações avançadas > Regras de Entrada > Nova
  Regra > Porta > TCP > 8000 > Permitir a conexão)
